<?php
$hash = '$2y$10$eW5T9tUCJW13Aq92.L5fxO0GnUx6EyVR96avEKmZtVJlNNHpQbePq'; // the hash from the database
$password = 'password123'; // the plain text password you’re testing

if (password_verify($password, $hash)) {
    echo "Password matches!";
} else {
    echo "Password does not match.";
}
?>
