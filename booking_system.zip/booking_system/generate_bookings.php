<?php
session_start();

// Include the DOMPDF library
require 'C:\Users\Bruce Mdluli\Downloads\xxampp\htdocs\booking_system\dompdf\autoload.inc.php';

use Dompdf\Dompdf;

// Database connection variables
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbie_nail_bar_dashboard"; // Update if your database name differs

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch booking data, including status and updated_at
$sql = "SELECT id, name, email, phone, services, date, time, payment_method, created_at, status, updated_at FROM bookings";
$result = $conn->query($sql);

// Generate HTML content for the PDF
$html = '
<!DOCTYPE html>
<html>
<head>
    <title>Bookings Report</title>
    <style>
        body { font-family: Arial, sans-serif; }
        h1 { text-align: center; }
        img.logo { display: block; margin: 0 auto 20px; width: 150px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Bookings Report for Barbie Nail Bar</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Services</th>
            <th>Date</th>
            <th>Time</th>
            <th>Payment Method</th>
            <th>Status</th>
            <th>Created At</th>
            <th>Last Updated</th>
        </tr>';

// Populate the table with booking data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $html .= '<tr>
                    <td>' . htmlspecialchars($row["id"]) . '</td>
                    <td>' . htmlspecialchars($row["name"]) . '</td>
                    <td>' . htmlspecialchars($row["email"]) . '</td>
                    <td>' . htmlspecialchars($row["phone"]) . '</td>
                    <td>' . htmlspecialchars($row["services"]) . '</td>
                    <td>' . htmlspecialchars($row["date"]) . '</td>
                    <td>' . htmlspecialchars($row["time"]) . '</td>
                    <td>' . htmlspecialchars($row["payment_method"]) . '</td>
                    <td>' . htmlspecialchars($row["status"]) . '</td>
                    <td>' . htmlspecialchars($row["created_at"]) . '</td>
                    <td>' . htmlspecialchars($row["updated_at"]) . '</td>
                  </tr>';
    }
} else {
    $html .= '<tr><td colspan="11">No bookings found.</td></tr>';
}

$html .= '
    </table>
</body>
</html>
';

// Instantiate and use the DOMPDF class
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Output the generated PDF to the browser
$dompdf->stream("bookings_report.pdf", ["Attachment" => true]);

// Close connection
$conn->close();
?>
