<?php
// Start session to access session variables
session_start();

// Database connection
$servername = "your_server_name"; // e.g., "localhost"
$username = "root";       // e.g., "root"
$password = " ";       // your database password
$dbname = "barbie_nail_bar_dashboard";    // your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// For page visit tracking
$user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : NULL; // Null if no user logged in

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO visits (user_id, type) VALUES (?, ?)");
$type = 'visit'; // Type of visit
$stmt->bind_param("is", $user_id, $type);

// Execute the statement
$stmt->execute();

// Close connections
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Page Title</title>
</head>
<body>
    <h1>Welcome to Your Page!</h1>
    <!-- Page Content -->
</body>
</html>
