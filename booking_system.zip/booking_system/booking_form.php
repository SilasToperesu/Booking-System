<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
            padding: 20px;
        }
        .container {
            max-width: 600px; 
            margin: 0 auto; 
            padding: 20px; 
            background: white; 
            border-radius: 8px; 
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center; 
            font-size: 2em; 
        }
        .service-category {
            cursor: pointer;
            padding: 10px;
            background-color: #f1f1f1;
            border-radius: 5px;
            margin: 5px 0;
        }
        .service-list {
            display: none;
            padding-left: 20px;
        }
        .checkout-container {
            margin-top: 20px;
        }
        .total-display {
            font-weight: bold;
            margin-bottom: 10px;
        }
        input {
            width: calc(100% - 20px);
            padding: 10px; 
            margin: 10px 0; 
            font-size: 1em; 
            border: 1px solid #ccc; 
            border-radius: 5px; 
            box-sizing: border-box; 
        }
        input, button {
            width: 100%; 
            padding: 15px; 
            margin: 10px 0; 
            font-size: 1.2em; 
            border: 1px solid #ccc; 
            border-radius: 5px; 
        }
        button {
            background-color: #007bff; 
            color: white; 
            border: none; 
            cursor: pointer; 
        }
        button:hover {
            background-color: #0056b3; 
        }
        .payment-container, .card-popup, .eft-popup {
            display: none; 
            margin-top: 20px; 
            padding: 20px; 
            border: 1px solid #ccc; 
            border-radius: 5px; 
            background-color: #f9f9f9;
        }
        .payment-container h3, .card-popup h3, .eft-popup h3 {
            margin: 0 0 10px 0;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Booking Form</h2>
    <form action="process_booking.php" method="POST" onsubmit="return validateForm()">
        <input type="text" name="name" placeholder="Your Name" required><br>
        <input type="email" name="email" placeholder="Your Email" required><br>
        
        <label for="phone">Phone Number:</label>
        <input type="text" id="phone" name="phone" required>

        
        
        
        <input type="hidden" name="selected_services" id="selectedServices" required> <!-- Hidden input for selected services -->
        
        <h3>Choose Services:</h3>
        <div class="service-category" onclick="toggleServices('nails')">
            <strong>Nails</strong>
        </div>
        <div class="service-list" id="nails">
            <label><input type="radio" name="nail_service" data-price="200" onchange="updateSelectedServices()"> Plain Acrylic - R200</label><br>
            <label><input type="radio" name="nail_service" data-price="250" onchange="updateSelectedServices()"> Plain Long - R250</label><br>
            <label><input type="radio" name="nail_service" data-price="200" onchange="updateSelectedServices()"> French Tips Short - R200</label><br>
            <label><input type="radio" name="nail_service" data-price="250" onchange="updateSelectedServices()"> Medium Nails - R250</label><br>
            <label><input type="radio" name="nail_service" data-price="300" onchange="updateSelectedServices()"> Long Nails - R300</label><br>
            <label><input type="radio" name="nail_service" data-price="150" onchange="updateSelectedServices()"> Buff & Shine - R150</label><br>
            <label><input type="radio" name="nail_service" data-price="150" onchange="updateSelectedServices()"> Gel Overlay Plain - R150</label><br>
            <label><input type="radio" name="nail_service" data-price="80" onchange="updateSelectedServices()"> Soak Off - R80</label><br>
            <label><input type="radio" name="nail_service" data-price="200" onchange="updateSelectedServices()"> Gel Pedicure - R200</label><br>
        </div>

        <div class="service-category" onclick="toggleServices('eyelash')">
            <strong>Eyelash</strong>
        </div>
        <div class="service-list" id="eyelash">
            <label><input type="radio" name="eyelash_service" data-price="150" onchange="updateSelectedServices()"> Classic Lash - R150</label><br>
            <label><input type="radio" name="eyelash_service" data-price="200" onchange="updateSelectedServices()"> Volume Lash - R200</label><br>
            <label><input type="radio" name="eyelash_service" data-price="250" onchange="updateSelectedServices()"> Cateye Lash - R250</label><br>
            <label><input type="radio" name="eyelash_service" data-price="300" onchange="updateSelectedServices()"> Anime Lash - R300</label><br>
            <label><input type="radio" name="eyelash_service" data-price="300" onchange="updateSelectedServices()"> Hybrid Lash - R300</label><br>
            <label><input type="radio" name="eyelash_service" data-price="350" onchange="updateSelectedServices()"> Mega Volume Lash - R350</label><br>
            <label><input type="radio" name="eyelash_service" data-price="300" onchange="updateSelectedServices()"> Mink Lash - R300</label><br>
            <label><input type="radio" name="eyelash_service" data-price="250" onchange="updateSelectedServices()"> Wispy Lash - R250</label><br>
            <label><input type="radio" name="eyelash_service" data-price="300" onchange="updateSelectedServices()"> Colored Lash - R300</label><br>
        </div>

        <div class="service-category" onclick="toggleServices('eyebrows')">
            <strong>Eyebrows</strong>
        </div>
        <div class="service-list" id="eyebrows">
            <label><input type="radio" name="eyebrow_service" data-price="150" onchange="updateSelectedServices()"> Natural Eyebrow Shaping - R150</label><br>
            <label><input type="radio" name="eyebrow_service" data-price="200" onchange="updateSelectedServices()"> Waxing - R200</label><br>
            <label><input type="radio" name="eyebrow_service" data-price="250" onchange="updateSelectedServices()"> Tinting - R250</label><br>
            <label><input type="radio" name="eyebrow_service" data-price="300" onchange="updateSelectedServices()"> Threading - R300</label><br>
        </div>

        <div class="service-category" onclick="toggleServices('nail_courses')">
            <strong>Nail Courses</strong>
        </div>
        <div class="service-list" id="nail_courses">
            <label><input type="radio" name="nail_courses" data-price="800" onchange="updateSelectedServices()"> 1 Week - R800</label><br>
            <label><input type="radio" name="nail_courses" data-price="1500" onchange="updateSelectedServices()"> 2 Weeks - R1500</label><br>
            <label><input type="radio" name="nail_courses" data-price="2000" onchange="updateSelectedServices()"> 3 Weeks - R2000</label><br>
            <label><input type="radio" name="nail_courses" data-price="3000" onchange="updateSelectedServices()"> 4 Weeks - R3000</label><br>
        </div>



        <input type="date" name="date" id="datePicker" required><br>
        <input type="time" name="time" id="timePicker" required><br>
        <div class="total-display" id="totalDisplay">Total: R0.00, Deposit: R0.00</div>
        <div class="total-display" id="remainingAmountDisplay"></div>
        
        <div class="checkout-container">
            <button type="button" onclick="prepareBooking()">Pay 50% Deposit</button>
        </div>

        <div class="payment-container" id="paymentOptions">
            <h3>Select Payment Method:</h3>
            <label><input type="radio" name="payment_method" value="Card" onclick="showCardPopup()" required> Card</label><br>
            <label><input type="radio" name="payment_method" value="EFT" onclick="showEFTPopup()" required> EFT</label><br>
            <button type="submit">Complete Booking</button>
        </div>

       
        <div class="card-popup" id="cardPopup">
            <h3>Enter Card Details:</h3>
            <input type="text" name="card_name" placeholder="Name on Card" required><br>
            <input type="text" name="card_number" placeholder="Card Number" maxlength="16" required><br>
            <input type="text" name="expiry_date" id="expiry_date" placeholder="Expiry Date (MM/YY)" maxlength="5" required oninput="formatExpiryDate(this)">
            <input type="text" name="cvv" placeholder="CVV" maxlength="3" required><br>
        </div>

        
        <div class="eft-popup" id="eftPopup">
            <h3>Barbie Nail Bar Banking Details:</h3>
            <p>Bank: FNB</p>
            <p>Account Name: Barbie Nail Bar</p>
            <p>Account Number: 62760100017</p>
            <p>Branch Code: 250655</p>
            <p>Once payment has been made, send your proof of payment to +27 68 266 0852 with your name and email and reference</p>
            <p>Payments made with other banks need to be instant payment</p>
        </div>
    </form>
</div>

<script>
    let totalAmount = 0;

    function toggleServices(category) {
        const serviceList = document.getElementById(category);
        serviceList.style.display = serviceList.style.display === "block" ? "none" : "block";
    }

    function updateSelectedServices() {
        const selectedServices = document.querySelectorAll('input[type="radio"]:checked');
        totalAmount = Array.from(selectedServices).reduce((sum, service) => sum + parseInt(service.getAttribute('data-price')), 0);
        document.getElementById('selectedServices').value = Array.from(selectedServices).map(service => service.parentNode.textContent.trim()).join(', ');

        const deposit = (totalAmount * 0.5).toFixed(2);
        const remaining = (totalAmount * 0.5).toFixed(2);

        document.getElementById('totalDisplay').textContent = `Total: R${totalAmount.toFixed(2)}, Deposit: R${deposit}`;
        document.getElementById('remainingAmountDisplay').textContent = `You will be required to pay the remaining 50% (R${remaining}) in person on the day of the appointment.`;
    }

    function prepareBooking() {
        if (totalAmount > 0) {
            document.getElementById('paymentOptions').style.display = "block"; 
        } else {
            alert("Please select at least one service.");
        }
    }

    function showCardPopup() {
        document.getElementById('cardPopup').style.display = "block";
        document.getElementById('eftPopup').style.display = "none";
    }

    function showEFTPopup() {
        document.getElementById('eftPopup').style.display = "block";
        document.getElementById('cardPopup').style.display = "none";
    }

    function validateForm() {
        const email = document.querySelector('input[name="email"]').value;
        const date = document.getElementById('datePicker').value;
        const time = document.getElementById('timePicker').value;
        const phoneNumber = document.getElementById('phone-number').value;
        const currentDate = new Date();
        const selectedDate = new Date(date + 'T' + time);

        if (!validateEmail(email)) {
            alert("Please enter a valid email address.");
            return false;
        }

        if (!validatePhoneNumber(phoneNumber)) {
            alert("Please enter a valid 10-digit South African phone number.");
            return false;
        }

        if (selectedDate < currentDate || selectedDate.getHours() < 8 || selectedDate.getHours() > 18) {
            alert("Please select a valid date and time within the salon's operating hours (8 AM - 6 PM).");
            return false;
        }

        return true;
    }

    function validateEmail(email) {
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailPattern.test(email);
    }

    function validatePhoneNumber(phoneNumber) {
        const phonePattern = /^[0-9]{10}$/;
        return phonePattern.test(phoneNumber);
    }

    document.getElementById('datePicker').setAttribute('min', new Date().toISOString().split('T')[0]);
    
    function formatExpiryDate(input) {
        var value = input.value.replace(/\D/g, '');
        if (value.length > 2) {
            value = value.slice(0, 2) + '/' + value.slice(2);
        }
        input.value = value;
    }

    window.onload = function() {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('datePicker').setAttribute('min', today);
    };
</script>
</body>
</html>
<?php
include 'db_config.php'; // Include the new database connection file
?>

