<?php 
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection settings
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "barbie_nail_bar_dashboard";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Step 1: Handle initial booking form submission
    if (isset($_POST['phone']) && !isset($_POST['otp'])) {
        // Save form data to session
        $_SESSION['name'] = $_POST['name'] ?? '';
        $_SESSION['email'] = $_POST['email'] ?? '';
        $_SESSION['phone'] = $_POST['phone'] ?? '';
        $_SESSION['selected_services'] = $_POST['selected_services'] ?? '';
        $_SESSION['date'] = $_POST['date'] ?? '';
        $_SESSION['time'] = $_POST['time'] ?? '';
        $_SESSION['payment_method'] = $_POST['payment_method'] ?? '';

        // Generate and store OTP in session
        $_SESSION['generated_otp'] = rand(100000, 999999);
        echo "OTP sent successfully: " . $_SESSION['generated_otp'] . ". <a href='process_booking.php'>Enter OTP</a>";
        exit;
    }

    // Step 2: Handle OTP verification
    if (isset($_POST['otp'])) {
        $entered_otp = $_POST['otp'] ?? '';
        
        if ($entered_otp == $_SESSION['generated_otp']) {
            // Insert booking into the database
            $stmt = $conn->prepare("INSERT INTO bookings (name, email, phone, services, date, time, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssss", $_SESSION['name'], $_SESSION['email'], $_SESSION['phone'], $_SESSION['selected_services'], $_SESSION['date'], $_SESSION['time'], $_SESSION['payment_method']);

            if ($stmt->execute()) {
                echo "Booking successful!";
                session_destroy(); // Clear session data after successful booking
                header("Refresh:2; url=success_page.php"); // Redirect to a success page
                exit;
            } else {
                echo "Error executing statement: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Incorrect OTP. Please try again.";
        }
    }

    // Close the connection if it's open
    if (isset($conn) && $conn) {
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enter OTP</title>
</head>
<body>
    <?php if (isset($_SESSION['generated_otp'])): ?>
        <h2>Enter OTP</h2>
        <form method="POST" action="process_booking.php">
            <label for="otp">OTP:</label>
            <input type="text" id="otp" name="otp" required>
            <button type="submit">Verify OTP</button>
        </form>
    <?php else: ?>
        <h2>No OTP generated</h2>
    <?php endif; ?>
    
</body>
</html>
