<?php
$servername = "localhost";
$username = "root"; // or your MySQL username
$password = ""; // Leave blank if you have no password
$dbname = "barbie_nail_bar_dashboard"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
$conn->close();
?>
