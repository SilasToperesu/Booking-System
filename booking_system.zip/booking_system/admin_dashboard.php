<?php
session_start();
include 'db_connection.php';
include 'fetch_statistics.php'; // Include the fetch statistics function

// Ensure the user is logged in and is an admin
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: admin_login.php');
    exit;
}

$statistics = fetch_statistics($conn); // Fetch statistics

// Fetch services from the database
$services_result = $conn->query("SELECT * FROM services");
$services = $services_result->fetch_all(MYSQLI_ASSOC);

// Handle add service
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_service'])) {
    $service_name = $conn->real_escape_string($_POST['service_name']);
    $conn->query("INSERT INTO services (service_name) VALUES ('$service_name')");
    header('Location: admin_dashboard.php'); // Redirect back to the dashboard
    exit;
}

// Handle delete service
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_service'])) {
    $service_id = (int)$_POST['service_id'];
    $conn->query("DELETE FROM services WHERE id = $service_id");
    header('Location: admin_dashboard.php'); // Redirect back to the dashboard
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Admin Dashboard</h1>
        <div class="statistics">
            <h2>Statistics</h2>
            <p>Total Signups: <span id="total-signups"><?= $statistics['total_signups'] ?></span></p>
            <p>Total Logins: <span id="total-logins"><?= $statistics['total_logins'] ?></span></p>
            <p>Total Visits: <span id="total-visits"><?= $statistics['total_visits'] ?></span></p>
        </div>
        <button id="generate-report">Generate Report</button>
        
        <div class="service-management">
            <h2>Manage Services</h2>
            <form id="service-form" action="admin_dashboard.php" method="POST">
                <input type="text" id="service-name" name="service_name" placeholder="Service Name" required>
                <button type="submit" name="add_service">Add Service</button>
            </form>

            <div id="services-list">
                <h3>Existing Services</h3>
                <ul>
                    <?php foreach ($services as $service): ?>
                        <li>
                            <?= htmlspecialchars($service['service_name']) ?>
                            <form action="admin_dashboard.php" method="POST" style="display:inline;">
                                <input type="hidden" name="service_id" value="<?= $service['id'] ?>">
                                <button type="submit" name="delete_service">Delete</button>
                            </form>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>

    <script src="dashboard.js"></script>
</body>
</html>
