<?php
$host = 'localhost';
$user = 'root'; // Default username for XAMPP
$pass = ''; // Default password for XAMPP (usually empty)
$dbname = "my_new_booking_db"; // Replace with your actual database name

// Create connection
$conn = mysqli_connect($host, $user, $pass, $dbname); // Use the same variable name

// Check connection
if (!$conn) { // Change $connection to $conn
    die("Connection failed: " . mysqli_connect_error());
}
?>
