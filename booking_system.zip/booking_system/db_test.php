<?php
require 'database.php';

if ($conn) {
    echo "Database connection successful!";
} else {
    echo "Database connection failed.";
}
