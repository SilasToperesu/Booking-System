<?php
session_start();

// Include the DOMPDF library
require 'C:\Users\Bruce Mdluli\Downloads\xxampp\htdocs\booking_system\dompdf\autoload.inc.php';

use Dompdf\Dompdf;

// Database connection variables
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbie_nail_bar_dashboard";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all user details for signups
$total_signups_query = "SELECT username, email, phone_number, signup_date FROM users";
$total_signups_result = $conn->query($total_signups_query);
$signup_data = [];
if ($total_signups_result->num_rows > 0) {
    while ($row = $total_signups_result->fetch_assoc()) {
        $signup_data[] = $row;
    }
}

// Fetch all login details with usernames and phone numbers
$total_logins_query = "SELECT u.username, u.email, u.phone_number, l.login_time 
                       FROM logins l 
                       JOIN users u ON l.user_id = u.id";
$total_logins_result = $conn->query($total_logins_query);
$login_data = [];
if ($total_logins_result->num_rows > 0) {
    while ($row = $total_logins_result->fetch_assoc()) {
        $login_data[] = $row;
    }
}

// Generate HTML content for the PDF
$html = '
<!DOCTYPE html>
<html>
<head>
    <title>Login and Signup Report</title>
    <style>
        body { font-family: Arial, sans-serif; }
        h1 { text-align: center; }
        img.logo { display: block; margin: 0 auto 20px; width: 150px; }
        .container { display: flex; justify-content: space-between; }
        .column { width: 48%; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Login and Signup Report for Barbie Nail Bar</h1>
    <div class="container">
        <div class="column">
            <h2>Total Signups: ' . count($signup_data) . '</h2>
            <table>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Signup Date/Time</th>
                </tr>';

foreach ($signup_data as $signup) {
    $html .= '<tr>
                <td>' . htmlspecialchars($signup['username']) . '</td>
                <td>' . htmlspecialchars($signup['email']) . '</td>
                <td>' . htmlspecialchars($signup['phone_number']) . '</td>
                <td>' . htmlspecialchars($signup['signup_date']) . '</td>
              </tr>';
}

$html .= '
            </table>
        </div>
        <div class="column">
            <h2>Total Logins: ' . count($login_data) . '</h2>
            <table>
                <tr>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Login Date/Time</th>
                </tr>';

foreach ($login_data as $login) {
    $html .= '<tr>
                <td>' . htmlspecialchars($login['username']) . '</td>
                <td>' . htmlspecialchars($login['email']) . '</td>
                <td>' . htmlspecialchars($login['phone_number']) . '</td>
                <td>' . htmlspecialchars($login['login_time']) . '</td>
              </tr>';
}

$html .= '
            </table>
        </div>
    </div>
</body>
</html>
';

// Instantiate and use the DOMPDF class
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Output the generated PDF to the browser
$dompdf->stream("login_signup_report.pdf", ["Attachment" => true]);

// Close connection
$conn->close();
?>
