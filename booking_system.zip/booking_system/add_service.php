<?php
require 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    
    // Handle image upload
    $image_path = 'uploads/' . basename($_FILES['image']['name']);
    if (move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
        // Insert service into database
        $stmt = $conn->prepare("INSERT INTO services (name, description, price, image_path) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssds", $name, $description, $price, $image_path);
        $stmt->execute();
        echo "Service added successfully!";
    } else {
        echo "Failed to upload image.";
    }
}
?>

<form method="POST" enctype="multipart/form-data">
    <label for="name">Service Name:</label>
    <input type="text" name="name" required>
    <label for="description">Description:</label>
    <textarea name="description" required></textarea>
    <label for="price">Price:</label>
    <input type="number" name="price" step="0.01" required>
    <label for="image">Service Image:</label>
    <input type="file" name="image" accept="image/*" required>
    <button type="submit">Add Service</button>
</form>
