<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f3f4f6;
        }
        .confirmation {
            text-align: center;
            padding: 20px;
            border: 1px solid #ccc;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        .confirmation h1 {
            color: #4CAF50;
        }
        .confirmation p {
            color: #333;
        }
        .confirmation a {
            display: inline-block;
            margin-top: 15px;
            padding: 10px 20px;
            color: #fff;
            background-color: #4CAF50;
            text-decoration: none;
            border-radius: 5px;
        }
        .confirmation a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="confirmation">
        <h1>Booking Successful!</h1>
        <p>Your booking has been confirmed. Thank you for choosing our service!</p>
        <a href="booking_form.php">Make Another Booking</a>
    </div>
</body>
</html>
