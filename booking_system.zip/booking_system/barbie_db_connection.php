<?php
// barbie_db_connection.php

$host = "localhost";
$username = "root";  // Username provided
$password = "";  // Password provided
$database = 'barbie_nail_bar_dashboard';

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
