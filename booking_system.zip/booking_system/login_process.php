<?php 
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo "Method Not Allowed";
    exit();
}
session_start();

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root"; // Update with your database username
$password = ""; // Update with your database password
$dbname = "barbie_nail_bar_dashboard"; // Ensure this is correct

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form data is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "Form submitted<br>"; // Debug statement

    // Validate that the necessary fields are set
    if (!isset($_POST['identifier'], $_POST['password'])) {
        echo "Form data not submitted correctly.";
        exit;
    }

    // Get the form data
    $identifier = $_POST['identifier'];
    $password = $_POST['password'];

    // Prepare the SQL query to get user ID, username, phone number, and hashed password
    $stmt = $conn->prepare("SELECT id, username, password, phone_number FROM users WHERE email = ? OR phone_number = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind and execute the statement
    $stmt->bind_param("ss", $identifier, $identifier);
    if (!$stmt->execute()) {
        echo "Error executing query: " . $stmt->error;
        exit;
    }

    $stmt->store_result();
    $stmt->bind_result($user_id, $username, $hashed_password, $phone_number);
    $stmt->fetch();

    // Check if the user was found
    if ($stmt->num_rows > 0) {
        echo "User found<br>"; // Debug statement

        // Verify the password matches the hashed password stored in the database
        if (password_verify($password, $hashed_password)) {
            echo "Password verified<br>"; // Debug statement

            // Login successful, set session variables
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $username;
            $_SESSION['user_id'] = $user_id;

            // Insert login record into the logins table with both username and phone number
            $insertLoginQuery = "INSERT INTO logins (user_id, username, phone_number) VALUES (?, ?, ?)";
            $loginStmt = $conn->prepare($insertLoginQuery);
            if (!$loginStmt) {
                die("Prepare failed: " . $conn->error);
            }

            $loginStmt->bind_param("iss", $user_id, $username, $phone_number);

            // Execute the statement for logging the login
            if ($loginStmt->execute()) {
                echo "Login logged<br>"; // Debug statement
                header("Location: home.php");
                exit();
            } else {
                echo "Error logging login action: " . $loginStmt->error;
            }

            $loginStmt->close();
        } else {
            // Wrong password
            echo "Incorrect password, please try again.";
        }
    } else {
        // User not found
        echo "No account found with that email or phone number.";
    }

    $stmt->close();
}

$conn->close();
?>
