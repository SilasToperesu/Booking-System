<?php
session_start(); // Start the session

// Unset all session variables and destroy the session
session_unset();
session_destroy();

// Redirect to the login page
header("Location: Login.html");
exit();
?>
