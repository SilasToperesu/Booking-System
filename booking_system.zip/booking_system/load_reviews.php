<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbie_nail_bar_dashboard";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT name, rating, review_text, review_image FROM reviews ORDER BY created_at DESC";
$result = $conn->query($sql);

$reviews = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $reviews[] = [
            'name' => $row['name'],
            'rating' => $row['rating'],
            'review_text' => $row['review_text'],
            'review_image' => $row['review_image']
        ];
    }
}

$conn->close();
header('Content-Type: application/json');
echo json_encode(['reviews' => $reviews]);
?>
