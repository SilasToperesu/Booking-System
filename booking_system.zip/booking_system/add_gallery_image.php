<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $caption = $_POST['caption'];
    $image_path = 'uploads/gallery/' . basename($_FILES['image']['name']);
    if (move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
        $stmt = $conn->prepare("INSERT INTO gallery (image_path, caption) VALUES (?, ?)");
        $stmt->bind_param("ss", $image_path, $caption);
        $stmt->execute();
        echo "Image added to gallery successfully!";
    } else {
        echo "Failed to upload image.";
    }
}
?>

<form method="POST" enctype="multipart/form-data">
    <label for="caption">Caption:</label>
    <input type="text" name="caption">
    <label for="image">Upload Image:</label>
    <input type="file" name="image" accept="image/*" required>
    <button type="submit">Add to Gallery</button>
</form>
