<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            overflow-x: hidden;
            background-color: #fafafa;
            font-family: 'Helvetica Neue', sans-serif;
            color: #444;
        }
        body {
            font-family: Arial, sans-serif;
        }
        .top-header {
            background-color: #f1d1e1;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9em;
        }
        .top-header .contact-info, .top-header .social-icons {
            display: flex;
            align-items: center;
        }
        .top-header .contact-info a, .top-header .social-icons a {
            color: black;
            text-decoration: none;
            margin-right: 15px;
        }
        .top-header .social-icons a {
            font-size: 1.2em;
            margin-left: 10px;
        }
        header {
            background-color: white;
            color: black;
            display: flex;
            align-items: center;
            padding: 15px 20px;
            width: 100%;
            position: sticky;
            top: 0;
            z-index: 10;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .logo {
            margin-right: 20px;
        }
        .logo img {
            max-width: 100%;
            height: auto;
        }
        nav {
            display: flex;
            align-items: center;
            margin-left: auto;
            font-size: 1.1em;
        }
        nav a {
            color: black;
            margin: 0 20px;
            text-decoration: none;
            font-weight: bold;
        }
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px;
        }
        .footer-social-icons a {
            margin-left: 10px;
            font-size: 1.5em;
            color: white;
        }
        .social-icons {
            text-align: center;
            padding: 10px 0;
        }
        .social-icons a {
            margin-left: 10px;
            font-size: 2em;
            color: black;
        }

        /* Aftercare Tips Section */
        .aftercare-tips {
            padding: 40px 20px;
            background-color: #f4f4f9;
            color: #444;
        }
        .aftercare-tips h2 {
            text-align: center;
            margin-bottom: 40px;
            font-size: 2.5em;
            color: gray;
        }
        .aftercare-section {
            display: flex;
            justify-content: space-between;
            margin-bottom: 40px;
            flex-wrap: wrap;
        }
        .tip, .video {
            flex-basis: 45%;
            margin-bottom: 20px;
        }
        .tip {
            font-size: 1.1em;
            padding: 10px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .video iframe {
            width: 100%;
            height: 300px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <div class="top-header">
        <div class="contact-info">
            <a href="tel:+27682660852"><i class="fas fa-phone"></i> +27682660852</a>
            <a href="mailto:BarbieNailBar777@gmail.com"><i class="fas fa-envelope"></i> BarbieNailBar777@gmail.com</a>
            <a href="#"><i class="fas fa-map-marker-alt"></i> 29 Flint Mazibuko Drive, Thembisa, GP, 1632, South Africa</a>
            <a href="#"><i class="fas fa-clock"></i> Mon-Sat: 9am - 6pm Closed on Sundays & Public Holidays</a>
        </div>
        <div class="social-icons">
            <a href="https://www.instagram.com/nails_by_seven" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.facebook.com/clayton.seven" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="https://www.tiktok.com/@nailsbyseven" target="_blank"><i class="fab fa-tiktok"></i></a>
            <a href="http://wa.me/27682660852" target="_blank"><i class="fab fa-whatsapp"></i></a>
        </div>
    </div>

    <header>
        <div class="logo">
            <img src="Barbie.png" width="230" height="230" alt="Business Logo">
        </div>
        <nav>
            <a href="#" onclick="logoutUser()">Logout</a>
            <a href="home.php">Home</a>
            <a href="About Us.html">About Us</a>
            <a href="service.php">Services</a>
            <a href="bookings.html">Bookings</a>
            <a href="Contact Page.html">Contact</a>
            <a href="aftercare.php">Aftercare Tips</a>
        </nav>
    </header>

    <!-- Aftercare Tips Section -->
    <section class="aftercare-tips">
        <h2>Aftercare Tips in between Appointments</h2>
        <?php
        // Database connection
        $host = "localhost";
        $username = "root";  // Username provided
        $password = "";  // Password provided
        $database = 'barbie_nail_bar_dashboard';

        $conn = new mysqli($host, $username, $password, $database);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch existing videos
        $result = $conn->query("SELECT * FROM aftercare_videos");
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Example video section, assuming each video has a unique title
                ?>
                 <div class="aftercare-section">
                    <div class="tip">
                        <h3><?php echo htmlspecialchars($row['tips_title']); ?></h3>
                        <p><?php echo htmlspecialchars($row['tips']); ?></p>
                    </div>
                    <div class="video">
                        <iframe src="<?php echo htmlspecialchars($row['video_url']); ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                       
                    </div>
            </div>
                <?php
            }
        } else {
            echo "<p>No videos available at this time.</p>";
        }

        $conn->close();
        ?>
    </section>
    
    <div class="social-icons">
        <a href="https://www.instagram.com/nails_by_seven?igsh=MWs2OWh3aG9qZzEzdA==" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://www.facebook.com/clayton.seven?mibextid=JRoKGi" target="_blank"><i class="fab fa-facebook"></i></a>
        <a href="https://www.tiktok.com/@nailsbyseven?_t=8oqRNDm88AQ&_r=1" target="_blank"><i class="fab fa-tiktok"></i></a>
        <a href="http://wa.me/27682660852" target="_blank"><i class="fab fa-whatsapp"></i></a>
    </div>

    <footer>
        <p>&copy; 2024 Barbie Nail Bar. All rights reserved.</p>
    </footer>
    <script>
        function logoutUser() {
            // Call the logout PHP file to end the session
            fetch('logout.php')
                .then(response => {
                    // After the session is destroyed, redirect to the login page
                    window.location.href = 'Login.html';
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }
    </script>
</body>
</html>
