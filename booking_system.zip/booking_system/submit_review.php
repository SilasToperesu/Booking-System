<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "barbie_nail_bar_dashboard";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get form data
    $name = $conn->real_escape_string($_POST['name']);
    $rating = (int)$_POST['rating'];
    $reviewText = $conn->real_escape_string($_POST['reviewText']);

    // Handle file uploads
    $profilePicPath = '';
    $reviewImagePath = '';

    // Create directories if they do not exist
    if (!file_exists('uploads/profile_pics')) {
        mkdir('uploads/profile_pics', 0777, true);
    }
    if (!file_exists('uploads/review_images')) {
        mkdir('uploads/review_images', 0777, true);
    }

    if (isset($_FILES['profilePic']) && $_FILES['profilePic']['error'] == UPLOAD_ERR_OK) {
        $profilePicTmpPath = $_FILES['profilePic']['tmp_name'];
        $profilePicPath = 'uploads/profile_pics/' . basename($_FILES['profilePic']['name']);
        move_uploaded_file($profilePicTmpPath, $profilePicPath);
    }

    if (isset($_FILES['reviewImage']) && $_FILES['reviewImage']['error'] == UPLOAD_ERR_OK) {
        $reviewImageTmpPath = $_FILES['reviewImage']['tmp_name'];
        $reviewImagePath = 'uploads/review_images/' . basename($_FILES['reviewImage']['name']);
        move_uploaded_file($reviewImageTmpPath, $reviewImagePath);
    }

    // Insert review into database
    $sql = "INSERT INTO reviews (name, rating, review_text, profile_pic, review_image, created_at) VALUES ('$name', $rating, '$reviewText', '$profilePicPath', '$reviewImagePath', NOW())";

    if ($conn->query($sql) === TRUE) {
        // Get the last inserted review to return it in the response
        $last_id = $conn->insert_id;
        $review = [
            'name' => $name,
            'rating' => $rating,
            'review_text' => $reviewText,
            'review_image' => $reviewImagePath,
            'created_at' => date("Y-m-d H:i:s")
        ];
        
        // Return response as JSON
        echo json_encode(['success' => true, 'message' => 'Review submitted successfully!', 'review' => $review]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $conn->error]);
    }

    $conn->close();
}
?>
