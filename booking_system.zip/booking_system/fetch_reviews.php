<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbie_nail_bar_dashboard";

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch reviews
$sql = "SELECT name, rating, review_text, profile_pic, review_image FROM reviews ORDER BY created_at DESC LIMIT 10";
$result = $conn->query($sql);

$reviews = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $reviews[] = [
            'name' => $row['name'],
            'rating' => $row['rating'],
            'review_text' => $row['review_text'],
            'profile_pic' => base64_encode($row['profile_pic']),
            'review_image' => base64_encode($row['review_image'])
        ];
    }
}

$conn->close();

// Output the reviews as JSON
header('Content-Type: application/json');
echo json_encode($reviews);
?>
