<?php
$db = new mysqli('localhost', 'root', '', 'barbie_nail_bar_dashboard');
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>
