<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbie_nail_bar_dashboard";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle video deletion
if (isset($_GET['delete'])) {
    $id = $conn->real_escape_string($_GET['delete']);
    $conn->query("DELETE FROM aftercare_videos WHERE id=$id");
}

// Handle video addition
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_video'])) {
    $video_title = $conn->real_escape_string($_POST['video_title']);
    $video_url = $conn->real_escape_string($_POST['video_url']);
    $tips_title = $conn->real_escape_string($_POST['tips_title']);
    $tips = $conn->real_escape_string($_POST['tips']);
    $conn->query("INSERT INTO aftercare_videos (video_title, video_url, tips_title, tips) VALUES ('$video_title', '$video_url', '$tips_title', '$tips')");
}

// Handle video editing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_video'])) {
    $id = $conn->real_escape_string($_POST['id']);
    $video_title = $conn->real_escape_string($_POST['video_title']);
    $video_url = $conn->real_escape_string($_POST['video_url']);
    $tips_title = $conn->real_escape_string($_POST['tips_title']);
    $tips = $conn->real_escape_string($_POST['tips']);
    $conn->query("UPDATE aftercare_videos SET video_title='$video_title', video_url='$video_url', tips_title='$tips_title', tips='$tips' WHERE id=$id");
}

// Fetch existing videos
$result = $conn->query("SELECT * FROM aftercare_videos");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Aftercare Videos</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #fef9f9; color: #444; }
        .container { width: 90%; max-width: 1200px; margin: auto; padding: 20px; }
        h1 { text-align: center; color: #c78a98; }
        .logo { display: block; margin: 0 auto 20px; max-width: 150px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
        th { background-color: #f8e1e9; }
        .form-container { margin-top: 20px; padding: 20px; background-color: #fdf5f7; border: 1px solid #ddd; }
        .form-container input[type="text"], .form-container textarea {
            width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px;
        }
        .form-container button { background-color: #e07a8e; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
        .form-container button:hover { background-color: #d06679; }
        .actions { display: flex; gap: 10px; }
        .edit-btn, .delete-btn { text-decoration: none; color: white; padding: 8px 12px; border-radius: 5px; }
        .edit-btn { background-color: #57a773; }
        .delete-btn { background-color: #e06666; }
    </style>
</head>
<body>

<div class="container">
    <img src="Barbie.png" alt="Business Logo" class="logo">
    <h1>Manage Aftercare Videos</h1>
    
    <table>
        <tr>
            <th>ID</th>
            <th>Video Title</th>
            <th>Video URL</th>
            <th>Tips Title</th>
            <th>Tips</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo htmlspecialchars($row['video_title']); ?></td>
            <td><?php echo htmlspecialchars($row['video_url']); ?></td>
            <td><?php echo htmlspecialchars($row['tips_title']); ?></td>
            <td><?php echo htmlspecialchars($row['tips']); ?></td>
            <td class="actions">
                <a href="edit_video.php?id=<?php echo $row['id']; ?>" class="edit-btn">Edit</a>
                <a href="?delete=<?php echo $row['id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this video?');">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>

    <div class="form-container">
        <h2>Add New Video</h2>
        <form method="POST">
            <input type="text" name="video_title" placeholder="Enter video title" required>
            <input type="text" name="video_url" placeholder="Enter YouTube video URL" required>
            <input type="text" name="tips_title" placeholder="Enter tips title" required>
            <textarea name="tips" placeholder="Enter aftercare tips here" rows="4" required></textarea>
            <button type="submit" name="add_video">Add Video</button>
        </form>
    </div>
</div>

</body>
</html>

<?php
$conn->close();
?>
