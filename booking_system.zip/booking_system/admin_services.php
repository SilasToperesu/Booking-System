<?php
require 'barbie_db_connection.php';

// Handle Add, Edit, Delete service actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                // Add service
                $name = $_POST['name'];
                $price = $_POST['price'];
                $imagePath = ''; // Placeholder for image path
                // Handle image upload
                if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $imagePath = 'images/' . basename($_FILES['image']['name']);
                    move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
                }
                $stmt = $conn->prepare("INSERT INTO services (name, price, image_url) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $name, $price, $imagePath);
                $stmt->execute();
                break;
                
            case 'edit':
                // Edit service
                $id = $_POST['id'];
                $name = $_POST['name'];
                $price = $_POST['price'];
                $imagePath = $_POST['existingImage']; // Use the existing image by default
                
                if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
                    $imagePath = 'images/' . basename($_FILES['image']['name']);
                    move_uploaded_file($_FILES['image']['tmp_name'], $imagePath);
                }
                $stmt = $conn->prepare("UPDATE services SET name = ?, price = ?, image_url = ? WHERE id = ?");
                $stmt->bind_param("sssi", $name, $price, $imagePath, $id);
                $stmt->execute();
                break;
                
            case 'delete':
                // Delete service
                $id = $_POST['id'];
                $stmt = $conn->prepare("DELETE FROM services WHERE id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                break;
        }
    }
}

// Fetch all services
$result = $conn->query("SELECT * FROM services");
$services = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f4f4f4;
        }
        h1, h2 {
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 15px;
            text-align: center;
        }
        th {
            background-color: #eee;
        }
        img {
            max-width: 100px;
            max-height: 100px;
        }
        .logo {
            display: block;
            margin: 0 auto 20px;
            width: 300px; /* Adjust the width as needed */
        }
    </style>
</head>
<body>
    <img src="Barbie.png" alt="Barbie Nail Bar Logo" class="logo">
    <h1>Admin Dashboard - Manage Services</h1>

    <table>
        <tr>
            <th>Image</th>
            <th>Name</th>
            <th>Price</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($services as $service): ?>
            <tr>
                <td><img src="<?php echo $service['image_url']; ?>" alt="<?php echo $service['name']; ?>"></td>
                <td><?php echo $service['name']; ?></td>
                <td>R<?php echo $service['price']; ?></td>
                <td>
                    <form method="POST" enctype="multipart/form-data" style="display: inline-block;">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" value="<?php echo $service['id']; ?>">
                        <input type="hidden" name="existingImage" value="<?php echo $service['image_url']; ?>">
                        <input type="text" name="name" value="<?php echo $service['name']; ?>" required>
                        <input type="text" name="price" value="<?php echo $service['price']; ?>" required>
                        <input type="file" name="image">
                        <button type="submit">Update</button>
                    </form>
                    <form method="POST" style="display: inline-block;">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" value="<?php echo $service['id']; ?>">
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h2>Add New Service</h2>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="action" value="add">
        <label>Name: <input type="text" name="name" required></label><br>
        <label>Price: <input type="text" name="price" required></label><br>
        <label>Image: <input type="file" name="image" required></label><br>
        <button type="submit">Save</button>
    </form>
</body>
</html>
