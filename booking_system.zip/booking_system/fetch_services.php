<?php
include 'barbie_nail_bar';

$query = "SELECT name, price, image_url FROM services";
$result = $conn->query($query);

$services = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $services[] = $row;
    }
}

header('Content-Type: application/json');
echo json_encode($services);
?>
