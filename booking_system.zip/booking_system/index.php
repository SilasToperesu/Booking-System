<?php
session_start();
require 'database.php';  // Make sure this file connects to the 'barbie_nail_bar_system' database
include 'track_visit.php';
// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    // Retrieve the user’s email and username from the session
    $username = isset($_SESSION['username']) ? htmlspecialchars($_SESSION['username']) : 'User';
    $email = isset($_SESSION['email']) ? htmlspecialchars($_SESSION['email']) : '';

    // Display welcome message with username (or email as a fallback)
    echo "<h1>Welcome back, " . ($username ?: $email) . "!</h1>";
    echo '<a href="logout.php">Logout</a>';

    // Record user activity as a visit
    $user_id = $_SESSION['user_id'] ?? 0;  // Use the logged-in user ID
    $action = 'visit';
    if ($user_id) {
        $stmt = $db->prepare("INSERT INTO user_activity (user_id, action, timestamp) VALUES (?, ?, NOW())");
        $stmt->bind_param("is", $user_id, $action);
        $stmt->execute();
        $stmt->close();
    }
} else {
    // If not logged in, redirect to the login page
    header("Location: Login.html");
    exit();
}
?>
