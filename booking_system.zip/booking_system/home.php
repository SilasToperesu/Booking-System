<?php include 'barbie_db_connection.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barbie Nail Bar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script> <!-- Include jQuery -->
    <script>
        $(document).ready(function() {
            $.ajax({
                url: 'get_username.php', // The PHP file that returns the username
                method: 'GET',
                success: function(response) {
                    if (response.username) {
                        $('#welcome-message').text('Welcome, ' + response.username + '!');
                    }
                }
            });
        });
    </script>
    <style>
        html, body {
            height: 100%;
            margin: 0;
            overflow-x: hidden;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
        }
        .top-header {
            background-color: #f1d1e1;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9em;
        }
        .top-header .contact-info, .top-header .social-icons {
            display: flex;
            align-items: center;
        }
        .top-header .contact-info a, .top-header .social-icons a {
            color: black;
            text-decoration: none;
            margin-right: 15px;
        }
        .top-header .social-icons a {
            font-size: 1.2em;
            margin-left: 10px;
        }
        header {
            background-color: white;
            color: black;
            display: flex;
            align-items: center;
            padding: 15px 20px;
            width: 100%;
            position: sticky;
            top: 0;
            z-index: 10;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .logo {
            margin-right: 20px;
        }
        .logo img {
            max-width: 100%;
            height: auto;
        }
        nav {
            display: flex;
            align-items: center;
            margin-left: auto;
            font-size: 1.1em;
        }
        nav a {
            color: black;
            margin: 0 20px;
            text-decoration: none;
            font-weight: bold;
        }
        .slideshow {
            position: relative;
            width: 100%;
            height: 75vh;
            margin: 0;
            overflow: hidden;
            z-index: 1;
        }
        .slideshow img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            position: absolute;
            top: 0;
            left: 0;
            opacity: 0;
            transition: opacity 1s ease-in-out;
        }
        .slideshow img.active {
            opacity: 1;
        }
        .welcome-section {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px;
            background-color: #fff;
        }
        .welcome-section .welcome-image {
            flex: 1;
            padding-right: 20px;
        }
        .welcome-section .welcome-image img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }
        .welcome-section .welcome-text {
            flex: 2;
            padding-left: 20px;
            text-align: center;
        }
        .welcome-section .welcome-text h2 {
            font-family: "Arial Narrow", Arial, sans-serif;
            font-size: 36px;
            font-weight: normal;
            text-transform: uppercase;
            color: black;
            margin-bottom: 20px;
        }
        .welcome-section .welcome-text p {
            font-family: "Arial Narrow", Arial, sans-serif;
            font-size: 22px;
            color: gray;
            line-height: 1.6;
        }
        .offer-section {
            text-align: center;
            padding: 40px;
            background-color: #fff;
        }
        .offer-section h2 {
            font-family: "Arial Narrow", Arial, sans-serif;
            font-size: 36px;
            font-weight: normal;
            text-transform: uppercase;
            color: black;
            margin-bottom: 30px;
        }
        .services {
            display: flex;
            justify-content: center;
            gap: 20px;
        }
        .service {
            text-align: center;
        }
        .service img {
            width: 280px;
            height: 280px;
            object-fit: cover;
            border-radius: 50%;
            border: 2px solid #f1d1e1;
            margin-bottom: 10px;
        }
        .service p {
            font-family: "Arial Narrow", Arial, sans-serif;
            font-size: 22px;
            color: gray;
            margin: 0;
        }
        footer {
            background-color: rgb(63, 58, 58);
            color: white;
            text-align: center;
            padding: 20px;
            margin-top: auto;
            position: relative;
            z-index: 10;
        }
        .footer-social-icons a {
            margin-left: 10px;
            font-size: 1.5em;
            color: white;
        }
        .social-icons {
            text-align: center;
            padding: 10px 0;
        }
        .social-icons a {
            margin-left: 10px;
            font-size: 2em;
            color: black;
        }
        .main-service-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            padding: 20px;
        }
        .main-service-item {
            flex: 1 1 200px;
            background-color: white;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .main-service-item img {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 8px 8px 0 0;
        }
        .main-service-item h3 {
            font-size: 1.2em;
            margin: 10px 0;
        }
        .main-service-item p {
            font-size: 1em;
            color: #333;
        }
    </style>
</head>
<body>

    <div class="top-header">
        <div class="contact-info">
            <a href="tel:+27682660852"><i class="fas fa-phone"></i> +27682660852</a>
            <a href="barbienailbar777@gmail.com"><i class="fas fa-envelope"></i>barbienailbar777@gmail.com</a>
            <a href="#"><i class="fas fa-map-marker-alt"></i> 29 Flint Mazibuko Drive, Thembisa, GP, 1632, South Africa</a>
            <a href="#"><i class="fas fa-clock"></i> Mon-Sat: 9am - 6pm Closed on Sundays & Public Holidays</a>
        </div>
        <div class="social-icons">
            <a href="https://www.instagram.com/nails_by_seven?igsh=MWs2OWh3aG9qZzEzdA==" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.facebook.com/clayton.seven?mibextid=JRoKGi" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="https://www.tiktok.com/@nailsbyseven?_t=8oqRNDm88AQ&_r=1" target="_blank"><i class="fab fa-tiktok"></i></a>
            <a href="http://wa.me/27682660852" target="_blank"><i class="fab fa-whatsapp"></i></a>
        </div>
    </div>

    <header>
        <div class="logo">
            <img src="Barbie.png" width="230" height="230" alt="Business Logo">
        </div>
        <nav>
            <a href="#" onclick="logoutUser()">Logout</a>
            <a href="About Us.html">About Us</a>
            <a href="service.php">Services</a>
            <a href="Bookings.html">Bookings</a>
            <a href="Contact Page.html">Contact</a>
            <a href="aftercare-tips.php">Aftercare Tips</a>
            

            
        </nav>
    </header>

    <div class="slideshow">
        <img src="images/landscape2.jpg" alt="Background Image 1" class="active">
        <img src="images/landscape 5.jpg" alt="Background Image 2">
        <img src="images/landscape3.jpg" alt="Background Image 3">
    </div>

    <div class="welcome-section">
        <div class="welcome-image">
            <img src="images/image-65_2.jpg" alt="Welcome Image">
            <div id="welcomeMessage"></div>
        </div>
        <div class="welcome-text">
            <h2>Welcome Bestie!</h2>
            <p>At Barbie Nail Bar we are dedicated to providing top-notch services with unparalleled customer satisfaction.</p>
            <p>Our goal is to exceed your expectations and offer you a chance to relax and indulge in something special.</p>
            <p>Experience the passion and dedication that Lucky and his team bring to their work.</p>
            <p>We understand how busy life can get and how precious quality time for yourself is.</p>
            <p>That's why we invite you to spend some time with us and explore our extensive range of nail and beauty treatments.</p>
            <p>Whether you're interested in lash extensions or eyebrow waxing, we have something perfect for you!</p>
            <p>Come and feel pampered at Barbie Nail Bar.</p>
        </div>
    </div>

    
    
        <div class="social-icons">
            <a href="https://www.instagram.com/nails_by_seven?igsh=MWs2OWh3aG9qZzEzdA==" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.facebook.com/clayton.seven?mibextid=JRoKGi" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="https://www.tiktok.com/@nailsbyseven?_t=8oqRNDm88AQ&_r=1" target="_blank"><i class="fab fa-tiktok"></i></a>
            <a href="http://wa.me/27682660852" target="_blank"><i class="fab fa-whatsapp"></i></a>
        </div>
    
        <footer>
            <p>&copy; 2024 Barbie Nail Bar. All rights reserved.</p>
        </footer>
    
        <script>
            // JavaScript to handle the slideshow
            const slides = document.querySelectorAll('.slideshow img');
            let currentSlide = 0;
    
            function showNextSlide() {
                slides[currentSlide].classList.remove('active');
                currentSlide = (currentSlide + 1) % slides.length;
                slides[currentSlide].classList.add('active');
            }
    
            setInterval(showNextSlide, 5000); // Change image every 5 seconds
            function getQueryParameter(name) {
            const urlParams = new URLSearchParams(window.location.search);
            return urlParams.get(name);
        }

            // Fetching services dynamically
            $.ajax({
                url: 'get_services.php', // The PHP file that fetches services from the database
                method: 'GET',
                dataType: 'json',
                success: function(services) {
                    services.forEach(service => {
                        $('#mainServiceContainer').append(`
                            <div class="main-service-item">
                                <img src="${service.image}" alt="${service.name}">
                                <h3>${service.name}</h3>
                                <p>${service.price}</p>
                            </div>
                        `);
                    });
                },
                error: function() {
                    console.error('Failed to fetch services.');
                }
            });

        // Get the username from the URL and display the welcome message
        const username = getQueryParameter('user');
        if (username) {
            document.getElementById('welcomeMessage').innerHTML = `<h1>Welcome back, ${username}!</h1>`;
        } else {
           
        }
        function logoutUser() {
        // Call the logout PHP file to end the session
        fetch('logout.php')
            .then(response => {
                // After the session is destroyed, redirect to the login page
                window.location.href = 'Login.html';
            })
            .catch(error => {
                console.error('Logout failed:', error);
            });
    }
    document.addEventListener('DOMContentLoaded', () => {
            fetch('fetch_services.php')
                .then(response => response.json())
                .then(services => {
                    const mainServiceContainer = document.getElementById('mainServiceContainer');
                    mainServiceContainer.innerHTML = '';

                    services.forEach(service => {
                        const mainServiceItem = document.createElement('div');
                        mainServiceItem.classList.add('main-service-item');

                        mainServiceItem.innerHTML = `
                            <img src="${service.image_url}" alt="${service.name}">
                            <h3>${service.name}</h3>
                            <p>Price: R${service.price}</p>
                        `;
                        mainServiceContainer.appendChild(mainServiceItem);
                    });
                })
                .catch(error => console.error('Error fetching services:', error));
        });
        </script>
    
    </body>
    </html> 