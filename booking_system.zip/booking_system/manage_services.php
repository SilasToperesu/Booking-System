<?php
session_start();
include 'db_connection.php';

// Add service functionality
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    mysqli_query($conn, "INSERT INTO services (name, description) VALUES ('$name', '$description')");
}

// Delete service functionality
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    mysqli_query($conn, "DELETE FROM services WHERE id = $id");
}

// Fetch all services
$services = mysqli_query($conn, "SELECT * FROM services");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Services</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Manage Services</h1>
    <form action="" method="post">
        <input type="text" name="name" placeholder="Service Name" required>
        <textarea name="description" placeholder="Service Description"></textarea>
        <button type="submit">Add Service</button>
    </form>
    <ul>
        <?php while ($service = mysqli_fetch_assoc($services)) { ?>
            <li>
                <?php echo $service['name']; ?> - <?php echo $service['description']; ?>
                <a href="?delete=<?php echo $service['id']; ?>">Delete</a>
            </li>
        <?php } ?>
    </ul>
</body>
</html>
