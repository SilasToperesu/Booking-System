<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$to = "mdlulizandile174@gmail.com"; // Change this to the recipient's email
$subject = "Test Email";
$message = "This is a test email sent using Gmail SMTP.";
$headers = "From: barbienailbar777@gmail.com";

if (mail($to, $subject, $message, $headers)) {
    echo "Email sent successfully!";
} else {
    echo "Failed to send email.";
}
?>
