<?php
require 'db_connection.php';
$result = $conn->query("SELECT * FROM services");

while ($service = $result->fetch_assoc()) {
    echo "<div class='service'>";
    echo "<h2>" . $service['name'] . "</h2>";
    echo "<img src='" . $service['image_path'] . "' alt='" . $service['name'] . "'>";
    echo "<p>" . $service['description'] . "</p>";
    echo "<p>Price: $" . $service['price'] . "</p>";
    echo "</div>";
}
?>
