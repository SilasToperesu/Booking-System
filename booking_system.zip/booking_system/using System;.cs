using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Events_in_C_Sharp
{
    internal class Program
    {
        public delegated void Notify (string message);
        public class Process
        {
            public event Notify ProcessCompleted;
            public void
            StartProcess()
            {
                console.WriteLine("Process Started!");
                onProcessCompleted("Process Completed!");
                }
                protected virtual void onProcessCompleted(string message)
                {
                    ProcessCompleted?.lnvoke(message);
                }
        }
        static void Main(string args)
        {
            Process process = new Process();
            proccess.Process+=message
            =>
            Console.WriteLine(message);
            process.StartProcess();

            Console.WriteLine("Press any key to exit");
            Consolde.ReadKey();
            }
    }
}