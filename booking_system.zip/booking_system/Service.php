<?php include 'barbie_db_connection.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            overflow-x: hidden;
            background-color: #fafafa;
            font-family: 'Helvetica Neue', sans-serif;
            color: #444;
        }
        body {
            font-family: Arial, sans-serif;
        }
        .top-header {
            background-color: #f1d1e1;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9em;
        }
        .top-header .contact-info, .top-header .social-icons {
            display: flex;
            align-items: center;
        }
        .top-header .contact-info a, .top-header .social-icons a {
            color: black;
            text-decoration: none;
            margin-right: 15px;
        }
        .top-header .social-icons a {
            font-size: 1.2em;
            margin-left: 10px;
        }
        header {
            background-color: white;
            color: black;
            display: flex;
            align-items: center;
            padding: 15px 20px;
            width: 100%;
            position: sticky;
            top: 0;
            z-index: 10;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .logo {
            margin-right: 20px;
        }
        .logo img {
            max-width: 100%;
            height: auto;
        }
        nav {
            display: flex;
            align-items: center;
            margin-left: auto;
            font-size: 1.1em;
        }
        nav a {
            color: black;
            margin: 0 20px;
            text-decoration: none;
            font-weight: bold;
        }
        .services-container {
            position: relative;
            margin: 50px 0;
            text-align: center;
        }
        .services-title {
            font-family: "Georgia", serif;
            color: #555;
            font-size: 3em;
            letter-spacing: 0.05em;
            position: relative;
            z-index: 1;
            display: inline-block;
            background-color: white; 
            padding: 0 20px;
        }
        .services-border {
            position: absolute;
            top: 50%;
            left: 0;
            width: 100%;
            height: 5px;
            background-color: #333;
            z-index: 0;
        }
        .services-content {
            display: flex;
            justify-content: space-between;
            padding: 20px;
        }
        .services-content p {
            width: 48%;
            text-align: justify;
            font-family: 'Helvetica Neue', sans-serif;
            font-size: 1.2em;
            line-height: 1.8;
            color: #333;
            margin-bottom: 30px;
        }
        
        .background-image-section {
            background-image: url('images/background.webp');
            background-size: cover;
            background-position: center;
            height: 600px; 
            margin: 40px 0;
        }
        .gallery-section {
            margin: 60px 0;
        }
        .gallery-section h2 {
            font-family: "Georgia", serif;
            color: #333;
            font-size: 2em;
            letter-spacing: 0.05em;
            position: relative;
            z-index: 1;
            display: inline-block;
            background-color: white; 
            padding: 0 20px;
        }
        .gallery-section h2::after { /* Line effect */
            content: "";
            display: block;
            width: 70%;
            height: 3px;
            background-color: #333;
            position: absolute;
            bottom: -10px; 
            left: 0;
            z-index: -1; 
        }
        .gallery {
            display: flex;
            overflow-x: auto; 
            scroll-snap-type: x mandatory;
            -webkit-overflow-scrolling: touch; 
        }
        .gallery-item {
            width: 220px;
            margin: 10px;
            text-align: center;
            scroll-snap-align: start; /* Aligns each item in the scroll */
        }
        .gallery-item img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s; 
        }
        .gallery-item img:hover {
            transform: scale(1.05); /* Added effect */
        }
        .style-name {
            font-weight: bold;
            font-size: 1.2em;
            margin-top: 10px;
            color: #444;
        }
        .style-price {
            font-size: 1.1em;
            color: gray;
            margin-top: 5px;
        }
        .book-now-button {
            display: inline-block;
            padding: 15px 30px;
            background-color: black; 
            color: white;
            text-decoration: none;
            font-size: 1.2em;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s;
        }

        .book-now-button:hover {
            background-color: #f1d1e1; 
            transform: scale(1.05); 
        }

        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px;
        }
        
        .footer-social-icons a {
            margin-left: 10px;
            font-size: 1.5em;
            color: white;
        }
        .social-icons {
            text-align: center;
            padding: 10px 0;
        }
        .social-icons a {
            margin-left: 10px;
            font-size: 2em;
            color: black;
        }
        .category-section {
            margin: 30px 0;
        }
        .category-section h3 {
            font-size: 2em;
            color: #333;
            margin-bottom: 20px;
            text-align: center;
        }
        .gallery {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .gallery-item {
            width: 220px;
            margin: 10px;
            text-align: center;
            scroll-snap-align: start;
        }
        
    </style>
</head>
<body>
    <div class="top-header">
        <div class="contact-info">
            <a href="tel:+27682660852"><i class="fas fa-phone"></i> +27682660852</a>
            <a href="mailto:barbienailbar777@gmail.com"><i class="fas fa-envelope"></i> barbienailbar777@gmail.com</a>
            <a href="#"><i class="fas fa-map-marker-alt"></i> 29 Flint Mazibuko Drive, Thembisa, GP, 1632, South Africa</a>
            <a href="#"><i class="fas fa-clock"></i> Mon-Sat: 9am - 6pm Closed on Sundays & Public Holidays</a>
        </div>
        <div class="social-icons">
            <a href="https://www.instagram.com/nails_by_seven" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.facebook.com/clayton.seven" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="https://www.tiktok.com/@nailsbyseven" target="_blank"><i class="fab fa-tiktok"></i></a>
            <a href="http://wa.me/27605834271" target="_blank"><i class="fab fa-whatsapp"></i></a>
        </div>
    </div>

    <header>
        <div class="logo">
            <img src="Barbie.png" width="230" height="230" alt="Business Logo">
        </div>
        <nav>
            <a href="#" onclick="logoutUser()">Logout</a>
            <a href="home.php">Home</a>
            <a href="About Us.html">About Us</a>
            <a href="bookings.html">Bookings</a>
            <a href="Contact Page.html">Contact</a>
            <a href="aftercare-tips.php">Aftercare Tips</a>
        </nav>
    </header>

    <section>
        <div class="services-container">
            <div class="services-border"></div>
            <div class="services-title">SERVICES</div>
        </div>
        
        <div class="services-content">
            <p>At Barbie Nail Bar, located in Tembisa, we are focused on providing professional services with the highest levels of customer satisfaction and will aim to do everything we can to meet your expectations. We offer you the chance to relax and treat yourself to something special.</p>
            <p>We understand that you are busy and that quality time for yourself might be a scarce treat. Therefore, we invite you to spend some time with us experiencing the range of pampering services we have on offer. Check out our latest services below!</p>
        </div>

        <div class="background-image-section"></div>
        <div class="services-content">
        <p>Here at Barbie Nail Bar, we believe in celebrating beauty and creativity. Feel free to browse through our stunning selection of nail art, eyelashes, and eyebrow styles that we offer at our salon. Each image is a doorway to inspiration, showcasing the artistry and flair that our talented team brings to every service. Whether you’re in the mood for something bold and vibrant or elegant and subtle, our gallery is designed to help you choose your next fabulous look! So, dive in and let your imagination run wild!</p>
            <p>Get ready to unleash your inner diva! Our gallery is not just a showcase; it's a vibrant playground of styles and trends waiting to be explored! From mesmerizing nail designs that sparkle with personality to enchanting eyelash extensions that enhance your natural beauty, we've curated a collection that caters to every taste. So take a stroll through our fabulous gallery, let your creativity flow, and find the perfect look that speaks to you. Remember, your next beauty adventure starts here—let’s create something spectacular together!</p>
    </div>
    <div class="services-content">
        <p>We pride ourselves on offering an extensive range of beauty services that go beyond just nails, eyelashes, and eyebrows. Our talented team of professionals is dedicated to providing you with the highest quality treatments, ensuring that you leave feeling pampered and beautiful. Whether you're looking for a classic manicure, stunning lash extensions, or perfectly shaped brows, we have you covered. Our commitment to customer satisfaction means that every visit is a delightful experience, tailored to meet your individual needs and preferences.</p>
            <p>In addition to our exceptional beauty services, Barbie Nail Bar also provides comprehensive nail courses designed for those eager to learn or enhance their skills. Whether you're a beginner wanting to explore the art of nail design or a seasoned professional seeking to refine your techniques, our courses offer expert guidance and hands-on training. Join us to unlock your creativity and elevate your skills in a supportive and inspiring environment. At Barbie Nail Bar, we believe that beauty is not just about looking good—it's about feeling empowered and confident in your abilities.</p>
    </div>
        <div class="gallery-section">
            <h2>Our Styles and Services</h2>
            <div class="gallery">
            <?php
                    // Fetch services from the database
                    $query = "SELECT name, price, image_url FROM services"; // Ensure correct column name
                    $result = $conn->query($query);

                    if ($result && $result->num_rows > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            echo '<div class="gallery-item">';
                            echo '<img src="' . $row['image_url'] . '" alt="Service Image">';
                            echo '<div class="style-name">' . $row['name'] . '</div>';
                            echo '<div class="style-price">Price: ' . $row['price'] . '</div>';
                            echo '</div>';
                        }
                    } else {
                        echo '<p>No services available at the moment.</p>';
                    }
                    $conn->close(); // Close the database connection
                ?>
            </div>
        </div>
        <div style="text-align: center; margin: 20px;">
            <a href="bookings.html" class="book-now-button">Book Now</a>
        </div>
    </section>
    <div class="social-icons">
        <a href="https://www.instagram.com/nails_by_seven?igsh=MWs2OWh3aG9qZzEzdA==" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://www.facebook.com/clayton.seven?mibextid=JRoKGi" target="_blank"><i class="fab fa-facebook"></i></a>
        <a href="https://www.tiktok.com/@nailsbyseven?_t=8oqRNDm88AQ&_r=1" target="_blank"><i class="fab fa-tiktok"></i></a>
        <a href="http://wa.me/27682660852" target="_blank"><i class="fab fa-whatsapp"></i></a>
    </div>
    
    <footer>
        <p>&copy; 2024 Barbie Nail Bar. All rights reserved.</p>
    </footer>
        
</body>
</html>
