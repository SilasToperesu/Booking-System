<?php
$password = 'Zandile#101'; // Replace with your own password
echo password_hash($password, PASSWORD_DEFAULT);
