<?php
require 'db_connection.php'; // Include your database connection file

// Replace 'admin' and 'Zandile#101' with the desired username and password
$username = 'admin';
$password = 'Zandile#101'; // Use a secure password

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert the new admin user into the database
$stmt = $conn->prepare("INSERT INTO admin_users (username, password) VALUES (?, ?)");
$stmt->bind_param("ss", $username, $hashed_password);

if ($stmt->execute()) {
    echo "Admin user created successfully.";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
