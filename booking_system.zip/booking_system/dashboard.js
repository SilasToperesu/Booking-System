document.addEventListener('DOMContentLoaded', () => {
    fetchStatistics();

    document.getElementById('generate-report').addEventListener('click', generateReport);

    const serviceForm = document.getElementById('service-form');
    if (serviceForm) {
        serviceForm.addEventListener('submit', function(event) {
            event.preventDefault(); 
            const serviceName = document.getElementById('service-name').value;
            addService(serviceName);
        });
    }
});

function fetchStatistics() {
    fetch('fetch_statistics.php')
        .then(response => response.json())
        .then(data => {
            function fetchStatistics() {
                fetch('fetch_statistics.php')
                    .then(response => response.json())
                    .then(data => {
                        document.getElementById('total-signups').textContent = data.total_signups;
                        document.getElementById('signup-emails').innerHTML = data.signup_emails.join('<br>') || 'None'; // Display signups emails
                        document.getElementById('total-logins').textContent = data.total_logins;
                        document.getElementById('login-emails').innerHTML = data.login_emails.join('<br>') || 'None'; // Display login emails
                    })
                    .catch(err => console.error('Error fetching statistics:', err));
            }
            
function generateReport() {
    fetch('generate_report.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.blob();
        })
        .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.style.display = 'none';
            a.href = url;
            a.download = 'report.pdf'; 
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
        })
        .catch(err => console.error('Error generating report:', err));
}

function addService(serviceName) {
    fetch('admin_dashboard.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({ service_name: serviceName, add_service: 'true' })
    })
    .then(response => response.text())
    .then(data => {
        console.log(data); 
        window.location.reload();
    })
    .catch(err => console.error('Error adding service:', err));
}
