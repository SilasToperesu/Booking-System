<?php
session_start();

// Database connection
$host = "localhost";
        $username = "root";  // Username provided
        $password = "";  // Password provided
        $database = 'barbie_nail_bar_dashboard';

        $conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the video ID is set
if (!isset($_GET['id'])) {
    die("Video ID not specified.");
}

$id = $conn->real_escape_string($_GET['id']);

// Fetch video data for the specified ID
$result = $conn->query("SELECT * FROM aftercare_videos WHERE id = $id");
if ($result->num_rows == 0) {
    die("Video not found.");
}

$video = $result->fetch_assoc();

// Handle form submission for updating the video details
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_video'])) {
    $video_title = $conn->real_escape_string($_POST['video_title']);
    $video_url = $conn->real_escape_string($_POST['video_url']);
    $tips_title = $conn->real_escape_string($_POST['tips_title']);
    $tips = $conn->real_escape_string($_POST['tips']);
    
    $conn->query("UPDATE aftercare_videos SET video_title = '$video_title', video_url = '$video_url', tips_title = '$tips_title', tips = '$tips' WHERE id = $id");
    
    // Redirect back to the main dashboard after editing
    header("Location: admin_aftercare.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Video</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #fef9f9; color: #444; }
        .container { width: 90%; max-width: 600px; margin: auto; padding: 20px; background-color: #fdf5f7; border: 1px solid #ddd; border-radius: 10px; }
        h1 { text-align: center; color: #c78a98; }
        .form-group { margin-top: 15px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; }
        input[type="text"], textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
        button { background-color: #e07a8e; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin-top: 10px; width: 100%; }
        button:hover { background-color: #d06679; }
    </style>
</head>
<body>

<div class="container">
    <h1>Edit Video</h1>
    
    <form method="POST">
        <div class="form-group">
            <label for="video_title">Video Title</label>
            <input type="text" name="video_title" id="video_title" value="<?php echo htmlspecialchars($video['video_title']); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="video_url">Video URL</label>
            <input type="text" name="video_url" id="video_url" value="<?php echo htmlspecialchars($video['video_url']); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="tips_title">Tips Title</label>
            <input type="text" name="tips_title" id="tips_title" value="<?php echo htmlspecialchars($video['tips_title']); ?>" required>
        </div>
        
        <div class="form-group">
            <label for="tips">Tips</label>
            <textarea name="tips" id="tips" rows="4" required><?php echo htmlspecialchars($video['tips']); ?></textarea>
        </div>
        
        <button type="submit" name="update_video">Update Video</button>
    </form>
</div>

</body>
</html>

<?php
$conn->close();
?>
