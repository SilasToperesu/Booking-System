<?php
$result = $conn->query("SELECT * FROM gallery");

while ($image = $result->fetch_assoc()) {
    echo "<div class='gallery-item'>";
    echo "<img src='" . $image['image_path'] . "' alt='Gallery Image'>";
    if ($image['caption']) echo "<p>" . $image['caption'] . "</p>";
    echo "</div>";
}
?>
