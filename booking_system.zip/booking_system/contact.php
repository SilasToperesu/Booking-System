<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $cellNumber = $_POST['cell-number'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    $mail = new PHPMailer(true);

    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Your SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username   = 'barbienailbar777@gmail.com'; // Your Gmail address
        $mail->Password   = 'Zandile#101'; // Your Gmail app password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS
        $mail->Port       = 587; // TCP port
        

        // Set the sender's email and name
$mail->setFrom('barbienailbar777@gmail.com', 'Barbie Nail Bar');

// Add a recipient's email and name
$mail->addAddress('barbienailbar777@gmail.com', 'Barbie Nail Bar Team'); // Business email


        // Email content
        $mail->isHTML(true);
        $mail->Subject = 'New Inquiry from ' . $name . ' ' . $surname;
        $mail->Body    = "Name: $name $surname<br>Cell: $cellNumber<br>Email: $email<br>Message: $message";
        $mail->AltBody = "Name: $name $surname\nCell: $cellNumber\nEmail: $email\nMessage: $message";

        // Send the email
        $mail->send();
        echo 'Message has been sent';
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>
