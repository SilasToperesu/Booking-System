<?php
session_start();

// Include the DOMPDF library
require 'C:\Users\Bruce Mdluli\Downloads\xxampp\htdocs\booking_system\dompdf\autoload.inc.php'; 

use Dompdf\Dompdf;

// Database connection variables
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbie_nail_bar_dashboard";

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch statistics and emails
$total_signups_query = "SELECT COUNT(*) AS total, GROUP_CONCAT(email) AS emails FROM users";
$total_logins_query = "SELECT COUNT(*) AS total, GROUP_CONCAT(u.email) AS emails FROM logins l JOIN users u ON l.user_id = u.id";

$total_signups_result = $conn->query($total_signups_query);
$total_logins_result = $conn->query($total_logins_query);

$total_signups_data = $total_signups_result->fetch_assoc();
$total_logins_data = $total_logins_result->fetch_assoc();

$total_signups = $total_signups_data['total'];
$signup_emails = explode(",", $total_signups_data['emails']); 
$total_logins = $total_logins_data['total'];
$login_emails = explode(",", $total_logins_data['emails']);



// Generate HTML content for the PDF
$html = '
<!DOCTYPE html>
<html>
<head>
    <title>Report</title>
    <style>
        body { font-family: Arial, sans-serif; }
        h1 { text-align: center; }
        img.logo { display: block; margin: 0 auto 20px; width: 150px; }
        .container { display: flex; justify-content: space-between; }
        .column { width: 48%; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>Login and Signup Report For Barbie Nail Bar</h1>
    <div class="container">
        <div class="column">
            <h2>Total Signups: ' . $total_signups . '</h2>
            <table>
                <tr>
                    <th>Signup Emails</th>
                </tr>';
                
foreach ($signup_emails as $email) {
    $html .= '<tr><td>' . htmlspecialchars($email) . '</td></tr>';
}

$html .= '
            </table>
        </div>
        <div class="column">
            <h2>Total Logins: ' . $total_logins . '</h2>
            <table>
                <tr>
                    <th>Login Emails</th>
                </tr>';

foreach ($login_emails as $email) {
    $html .= '<tr><td>' . htmlspecialchars($email) . '</td></tr>';
}

$html .= '
            </table>
        </div>
    </div>
</body>
</html>
';

// Instantiate and use the DOMPDF class
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

// Output the generated PDF to browser
$dompdf->stream("report.pdf", ["Attachment" => true]);
?>
