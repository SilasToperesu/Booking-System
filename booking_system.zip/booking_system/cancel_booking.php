<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection variables
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbie_nail_bar_dashboard"; // Update if different

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle cancellation form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';

    // Update booking status to 'Cancelled' if record exists
    $stmt = $conn->prepare("UPDATE bookings SET status = 'Cancelled' WHERE name = ? AND email = ? AND phone = ?");
    $stmt->bind_param("sss", $name, $email, $phone);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        echo "<script>alert('Booking successfully cancelled.');</script>";
    } else {
        echo "<script>alert('No matching booking found or it has already been cancelled.');</script>";
    }
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cancel Booking</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Reset */
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        html, body {
            height: 100%;
            display: flex;
            flex-direction: column;
            font-family: Arial, sans-serif;
            background-color: #f8f8f8;
        }

        /* Top Header */
        .top-header {
            background-color: #f1d1e1;
            color: white;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.9em;
        }

        .top-header .contact-info, .top-header .social-icons {
            display: flex;
            align-items: center;
        }

        .top-header .contact-info a, .top-header .social-icons a {
            color: black;
            text-decoration: none;
            margin-right: 15px;
        }

        .top-header .social-icons a {
            font-size: 1.2em;
            margin-left: 10px;
        }

        /* Header */
        header {
            background-color: white;
            color: black;
            display: flex;
            align-items: center;
            padding: 10px 20px;
            width: 100%;
            position: sticky;
            top: 0;
            z-index: 10;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .logo img {
            width: 230px;
            height: auto;
        }
        nav {
            display: flex;
            align-items: center;
            margin-left: auto;
            font-size: 1.1em;
        }
        nav a {
            color: black;
            margin: 0 20px;
            text-decoration: none;
            font-weight: bold;
        }
        /* Main Content */
        main {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }

        h2 {
            margin-bottom: 20px;
            color: #333;
        }

        form {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            display: flex;
            flex-direction: column;
        }

        form label, form input, form button {
            margin-bottom: 15px;
        }

        form label {
            color: #333;
            font-weight: bold;
        }

        form input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 1em;
        }

        form button {
            padding: 10px;
            border: none;
            background-color: #f1d1e1;
            color: white;
            font-size: 1em;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
        }

        form button:hover {
            background-color: #e4a2b5;
        }

        /* Footer */
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .social-icons {
            display: flex;
            justify-content: center;
            padding: 10px 0;
        }

        .social-icons a {
            margin: 0 10px;
            font-size: 2em;
            color: black;
        }
        
        .social-icons a:hover {
            color: #f1d1e1;
        }
    </style>
</head>
<body>
    <!-- Top Header -->
    <div class="top-header">
        <div class="contact-info">
            <a href="tel:+270605834271"><i class="fas fa-phone"></i> +27605834271</a>
            <a href="mailto:barbienailbar777@gmail.com"><i class="fas fa-envelope"></i> barbienailbar777@gmail.com</a>
            <a href="#"><i class="fas fa-map-marker-alt"></i> 29 Flint Mazibuko Drive, Thembisa, GP, 1632, South Africa</a>
            <a href="#"><i class="fas fa-clock"></i> Mon-Sat: 9am - 6pm Closed on Sundays & Public Holidays</a>
        </div>
        <div class="social-icons">
            <a href="https://www.instagram.com/nails_by_seven?igsh=MWs2OWh3aG9qZzEzdA==" target="_blank"><i class="fab fa-instagram"></i></a>
            <a href="https://www.facebook.com/clayton.seven?mibextid=JRoKGi" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="https://www.tiktok.com/@nailsbyseven?_t=8oqRNDm88AQ&_r=1" target="_blank"><i class="fab fa-tiktok"></i></a>
            <a href="http://wa.me/27682660852" target="_blank"><i class="fab fa-whatsapp"></i></a>
        </div>
    </div>

    <!-- Header -->
    <header>
        <div class="logo">
            <img src="Barbie.png" alt="Business Logo">
        </div>
        <nav>
            <a href="bookings.html">Bookings</a>

        </nav>
    </header>

    <!-- Main Content -->
    <main>
        <h2>Cancel Your Appointment</h2>
        <form method="POST" action="cancel_booking.php">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" required>

            <button type="submit">Cancel Booking</button>
        </form>
    </main>

    <div class="social-icons">
        <a href="https://www.instagram.com/nails_by_seven?igsh=MWs2OWh3aG9qZzEzdA==" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="https://www.facebook.com/clayton.seven?mibextid=JRoKGi" target="_blank"><i class="fab fa-facebook"></i></a>
        <a href="https://www.tiktok.com/@nailsbyseven?_t=8oqRNDm88AQ&_r=1" target="_blank"><i class="fab fa-tiktok"></i></a>
        <a href="http://wa.me/27682660852" target="_blank"><i class="fab fa-whatsapp"></i></a>
    </div>

    <footer>
        <p>&copy; 2024 Barbie Nail Bar. All rights reserved.</p>
    </footer>
</body>
</html>
