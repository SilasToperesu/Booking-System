<?php
session_start();
if (isset($_SESSION['username'])) {
  echo "Welcome, <a href='profile.php'>" . $_SESSION['username'] . "</a> (<a href='logout.php'>Logout</a>)";
} else {
  echo "<a href='login_process.php'>Login</a> | <a href='signup.php'>Sign Up</a>";
}
?>
