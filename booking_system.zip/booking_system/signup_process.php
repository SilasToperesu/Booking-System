<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbie_nail_bar_dashboard";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'] ?? null;
    $phone = $_POST['phone_number'] ?? null;
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Ensure at least one of email or phone is provided
    if (empty($email) && empty($phone)) {
        echo "Please provide either an email or phone number.";
        exit;
    }

    // Validate username, password, and confirm password
    if (empty($username) || empty($password) || empty($confirm_password)) {
        echo "Username, password, and confirm password are required.";
        exit;
    }
    if ($password !== $confirm_password) {
        echo "Passwords do not match.";
        exit;
    }
    if (strlen($password) < 8) {
        echo "Password must be at least 8 characters long.";
        exit;
    }
    if ($email && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
        exit;
    }

    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Check for existing username
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    if ($stmt->num_rows > 0) {
        echo "Username already exists.";
        exit;
    }
    $stmt->close();

    // Check for existing email if provided
    if ($email) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            echo "Email already exists.";
            exit;
        }
        $stmt->close();
    }

    // Check for existing phone number if provided
    if ($phone) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE phone_number = ?");
        $stmt->bind_param("s", $phone);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            echo "Phone number already exists.";
            exit;
        }
        $stmt->close();
    }

    // If phone is empty, set it to null
    $phone = empty($phone) ? null : $phone;

    // Insert new user, using NULL for phone if not provided
    $stmt = $conn->prepare("INSERT INTO users (username, email, phone_number, password, signup_date) VALUES (?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssss", $username, $email, $phone, $hashed_password);

    if ($stmt->execute()) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['user_id'] = $conn->insert_id;

        // Log visit action
        $action = 'signup';
        $visitStmt = $conn->prepare("INSERT INTO visits (user_id, type, timestamp) VALUES (?, ?, NOW())");
        $visitStmt->bind_param("is", $_SESSION['user_id'], $action);
        $visitStmt->execute();
        $visitStmt->close();

        header("Location: home.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}
$conn->close();
?>
